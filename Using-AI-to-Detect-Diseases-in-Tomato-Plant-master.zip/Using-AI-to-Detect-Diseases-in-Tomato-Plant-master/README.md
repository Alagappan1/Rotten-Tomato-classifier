# Using-AI-to-Detect-Diseases-in-Tomato-Plant

Theme of Project- AI in agriculture  

Purpose 
Our purpose is to use AI to help us in detecting the various kinds of diseases found in the tomato plant, and then work on finding further solution to the problem. 

Tech Stack Used
- LeNet-5, a pioneering 7-level convolutional network by LeCun et al in 1998, was used to train our model which is based on Tensorflow and Keras frameworks.
-OpenCV python library was used for image processing part.
- Various other ML concepts were used to get the desired results.
- The model achieved 98.9% accuracy on validation data.

Advantages
It will be very helpful for farmers as it will provide an inexpensive way of taking proper care of there plants.; 
